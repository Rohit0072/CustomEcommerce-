import React from 'react'
import Navbar from '../Navbar/navbar'
import Footer from '../Footer/footer'

function Contact() {
  return (
    <>
      <Navbar />
      <Footer />
    </>
  )
}

export default Contact