import React from 'react'

function Error() {
  return (
    <>
        <h1>Error 404: Page Not Found</h1>
        <p>The page you're looking for doesn't exist.</p>
    </>
  )
}

export default Error
