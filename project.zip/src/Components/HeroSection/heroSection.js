import React from 'react'
import './heroSection.css'
import firstImage from '../../assets/heroSection.jpeg';
function HeroSection() {
    return (
        <>
            {/* <!-- Hero Section --> */}
            <section className="hero-section">
                <div className="hero-container">
                    <div className="hero-content">
                        <div className="hero-text">
                            <h1 className="hero-title">Discover the Latest Trends</h1>
                            <p className="hero-description">Shop our exclusive collection of fashion, electronics, and more with
                                amazing deals.</p>
                            <a href="#" className="hero-button">Shop Now</a>
                        </div>
                        <div className="hero-image-container">
                            <img src={firstImage} alt="Hero Image" className="hero-image" />
                        </div>
                    </div>
                </div>
            </section>

            {/* <!-- Featured Categories --> */}
            <section className="categories-section">
                <div className="categories-container">
                    <h2 className="categories-title">Featured Categories</h2>
                    <div className="categories-grid">
                        <div className="category-item">
                            <div className="category-icon-container">
                                <i className="fas fa-tshirt category-icon"></i>
                            </div>
                            <h3 className="category-name">Fashion</h3>
                        </div>
                        <div className="category-item">
                            <div className="category-icon-container">
                                <i className="fas fa-mobile-alt category-icon"></i>
                            </div>
                            <h3 className="category-name">Electronics</h3>
                        </div>
                        <div className="category-item">
                            <div className="category-icon-container">
                                <i className="fas fa-couch category-icon"></i>
                            </div>
                            <h3 className="category-name">Home & Living</h3>
                        </div>
                        <div className="category-item">
                            <div className="category-icon-container">
                                <i className="fas fa-heartbeat category-icon"></i>
                            </div>
                            <h3 className="category-name">Health & Beauty</h3>
                        </div>
                    </div>
                </div>
            </section>

            {/* <!-- Featured Products --> */}
            <section className="products-section">
                <div className="products-container">
                    <div className="products-header">
                        <h2 className="products-title">Featured Products</h2>
                        <a href="#" className="products-view-all">View All</a>
                    </div>
                    <div className="products-grid">
                        {/* <!-- Product 1 --> */}
                        <div className="product-card">
                            <div className="product-image-container">
                                <img src="https://placehold.co/150x150" alt="Product" className="product-image" />
                                <div className="product-wishlist">
                                    <i className="far fa-heart"></i>
                                </div>
                            </div>
                            <div className="product-details">
                                <h3 className="product-title">Premium T-Shirt</h3>
                                <div className="product-price">
                                    <span className="product-current-price">$45.00</span>
                                    <span className="product-original-price">$60.00</span>
                                </div>
                                <div className="product-rating">
                                    <div className="product-stars">
                                        <i className="fas fa-star"></i>
                                        <i className="fas fa-star"></i>
                                        <i className="fas fa-star"></i>
                                        <i className="fas fa-star"></i>
                                        <i className="fas fa-star-half-alt"></i>
                                    </div>
                                    <span className="product-reviews">(45)</span>
                                </div>
                            </div>
                        </div>

                        {/* <!-- Product 2 --> */}
                        <div className="product-card">
                            <div className="product-image-container">
                                <img src="https://placehold.co/150x150" alt="Product" className="product-image" />
                                <div className="product-wishlist">
                                    <i className="far fa-heart"></i>
                                </div>
                            </div>
                            <div className="product-details">
                                <h3 className="product-title">Wireless Headphones</h3>
                                <div className="product-price">
                                    <span className="product-current-price">$120.00</span>
                                    <span className="product-original-price">$150.00</span>
                                </div>
                                <div className="product-rating">
                                    <div className="product-stars">
                                        <i className="fas fa-star"></i>
                                        <i className="fas fa-star"></i>
                                        <i className="fas fa-star"></i>
                                        <i className="fas fa-star"></i>
                                        <i className="far fa-star"></i>
                                    </div>
                                    <span className="product-reviews">(32)</span>
                                </div>
                            </div>
                        </div>

                        {/* <!-- Product 3 --> */}
                        <div className="product-card">
                            <div className="product-image-container">
                                <img src="https://placehold.co/150x150" alt="Product" className="product-image" />
                                <div className="product-wishlist">
                                    <i className="far fa-heart"></i>
                                </div>
                            </div>
                            <div className="product-details">
                                <h3 className="product-title">Smart Watch</h3>
                                <div className="product-price">
                                    <span className="product-current-price">$225.00</span>
                                    <span className="product-original-price">$280.00</span>
                                </div>
                                <div className="product-rating">
                                    <div className="product-stars">
                                        <i className="fas fa-star"></i>
                                        <i className="fas fa-star"></i>
                                        <i className="fas fa-star"></i>
                                        <i className="fas fa-star"></i>
                                        <i className="fas fa-star"></i>
                                    </div>
                                    <span className="product-reviews">(59)</span>
                                </div>
                            </div>
                        </div>

                        {/* <!-- Product 4 --> */}
                        <div className="product-card">
                            <div className="product-image-container">
                                <img src="https://placehold.co/150x150" alt="Product" className="product-image" />
                                <div className="product-wishlist">
                                    <i className="far fa-heart"></i>
                                </div>
                            </div>
                            <div className="product-details">
                                <h3 className="product-title">Designer Handbag</h3>
                                <div className="product-price">
                                    <span className="product-current-price">$180.00</span>
                                    <span className="product-original-price">$220.00</span>
                                </div>
                                <div className="product-rating">
                                    <div className="product-stars">
                                        <i className="fas fa-star"></i>
                                        <i className="fas fa-star"></i>
                                        <i className="fas fa-star"></i>
                                        <i className="fas fa-star-half-alt"></i>
                                        <i className="far fa-star"></i>
                                    </div>
                                    <span className="product-reviews">(28)</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* <!-- Services Section --> */}
            <section className="Services-section">
                <div className="Services-container">
                    <div className="Services-grid">
                        <div className="Services-item">
                            <div className="Services-icon-container">
                                <i className="fas fa-truck Services-icon"></i>
                            </div>
                            <h3 className="Services-title">FREE AND FAST DELIVERY</h3>
                            <p className="Services-description">Free delivery for all orders over $140</p>
                        </div>
                        <div className="Services-item">
                            <div className="Services-icon-container">
                                <i className="fas fa-headset Services-icon"></i>
                            </div>
                            <h3 className="Services-title">24/7 CUSTOMER SERVICE</h3>
                            <p className="Services-description">Friendly 24/7 customer support</p>
                        </div>
                        <div className="Services-item">
                            <div className="Services-icon-container">
                                <i className="fas fa-shield-alt Services-icon"></i>
                            </div>
                            <h3 className="Services-title">MONEY BACK GUARANTEE</h3>
                            <p className="Services-description">We return money within 30 days</p>
                        </div>
                    </div>
                </div>
            </section>
        </>
    )
}

export default HeroSection
