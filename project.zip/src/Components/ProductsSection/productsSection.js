import React from 'react'
import './productsSection.css'
function ProductsSection() {
    return (
        <>
            <div className="products-section-container">
                {/* <!-- Header --> */}
                <div className="products-section-header">
                    <div className="products-section-label">
                        <span>Our Products</span>
                    </div>
                </div>

                {/* <!-- Title and Navigation --> */}
                <div className="products-section-title-nav">
                    <h2 className="products-section-heading">Explore Our Products</h2>
                    <div className="products-section-nav">
                        <button className="products-section-nav-btn">
                            <i className="fas fa-chevron-left"></i>
                        </button>
                        <button className="products-section-nav-btn">
                            <i className="fas fa-chevron-right"></i>
                        </button>
                    </div>
                </div>

                {/* <!-- Products Grid - First Row --> */}
                <div className="products-section-grid">
                    {/* <!-- Product 1 --> */}
                    <div className="products-section-product">
                        <div className="products-section-product-img-container">
                            <img src="https://placehold.co/150x150" alt="Dog Food" className="products-section-product-img"/>
                                <div className="products-section-product-actions">
                                    <button className="products-section-action-btn">
                                        <i className="far fa-heart"></i>
                                    </button>
                                    <button className="products-section-action-btn">
                                        <i className="far fa-eye"></i>
                                    </button>
                                </div>
                        </div>
                        <h3 className="products-section-product-title">Breed Dry Dog Food</h3>
                        <div className="products-section-product-price">
                            <span>$100</span>
                        </div>
                        <div className="products-section-product-rating">
                            <div className="products-section-stars">
                                <i className="fas fa-star products-section-star-filled"></i>
                                <i className="fas fa-star products-section-star-filled"></i>
                                <i className="fas fa-star products-section-star-filled"></i>
                                <i className="fas fa-star products-section-star-empty"></i>
                                <i className="fas fa-star products-section-star-empty"></i>
                            </div>
                            <span className="products-section-review-count">(38)</span>
                        </div>
                    </div>

                    {/* <!-- Product 2 --> */}
                    <div className="products-section-product">
                        <div className="products-section-product-img-container">
                            <img src="https://placehold.co/150x150" alt="Canon Camera" className="products-section-product-img"/>
                                <div className="products-section-product-actions">
                                    <button className="products-section-action-btn">
                                        <i className="far fa-heart"></i>
                                    </button>
                                    <button className="products-section-action-btn">
                                        <i className="far fa-eye"></i>
                                    </button>
                                </div>
                                <div className="products-section-add-to-cart">
                                    <span>Add To Cart</span>
                                </div>
                        </div>
                        <h3 className="products-section-product-title">CANON EOS DSLR Camera</h3>
                        <div className="products-section-product-price">
                            <span>$350</span>
                        </div>
                        <div className="products-section-product-rating">
                            <div className="products-section-stars">
                                <i className="fas fa-star products-section-star-filled"></i>
                                <i className="fas fa-star products-section-star-filled"></i>
                                <i className="fas fa-star products-section-star-filled"></i>
                                <i className="fas fa-star products-section-star-filled"></i>
                                <i className="fas fa-star products-section-star-filled"></i>
                            </div>
                            <span className="products-section-review-count">(98)</span>
                        </div>
                    </div>

                    {/* <!-- Product 3 --> */}
                    <div className="products-section-product">
                        <div className="products-section-product-img-container">
                            <img src="https://placehold.co/150x150" alt="Gaming Laptop" className="products-section-product-img"/>
                                <div className="products-section-product-actions">
                                    <button className="products-section-action-btn">
                                        <i className="far fa-heart"></i>
                                    </button>
                                    <button className="products-section-action-btn">
                                        <i className="far fa-eye"></i>
                                    </button>
                                </div>
                        </div>
                        <h3 className="products-section-product-title">ASUS FHD Gaming Laptop</h3>
                        <div className="products-section-product-price">
                            <span>$700</span>
                        </div>
                        <div className="products-section-product-rating">
                            <div className="products-section-stars">
                                <i className="fas fa-star products-section-star-filled"></i>
                                <i className="fas fa-star products-section-star-filled"></i>
                                <i className="fas fa-star products-section-star-filled"></i>
                                <i className="fas fa-star products-section-star-filled"></i>
                                <i className="fas fa-star products-section-star-filled"></i>
                            </div>
                            <span className="products-section-review-count">(225)</span>
                        </div>
                    </div>

                    {/* <!-- Product 4 --> */}
                    <div className="products-section-product">
                        <div className="products-section-product-img-container">
                            <img src="https://placehold.co/150x150" alt="Curology Product" className="products-section-product-img"/>
                                <div className="products-section-product-actions">
                                    <button className="products-section-action-btn">
                                        <i className="far fa-heart"></i>
                                    </button>
                                    <button className="products-section-action-btn">
                                        <i className="far fa-eye"></i>
                                    </button>
                                </div>
                        </div>
                        <h3 className="products-section-product-title">Curology Product Set</h3>
                        <div className="products-section-product-price">
                            <span>$500</span>
                        </div>
                        <div className="products-section-product-rating">
                            <div className="products-section-stars">
                                <i className="fas fa-star products-section-star-filled"></i>
                                <i className="fas fa-star products-section-star-filled"></i>
                                <i className="fas fa-star products-section-star-filled"></i>
                                <i className="fas fa-star products-section-star-filled"></i>
                                <i className="fas fa-star products-section-star-empty"></i>
                            </div>
                            <span className="products-section-review-count">(145)</span>
                        </div>
                    </div>
                </div>

                {/* <!-- Products Grid - Second Row --> */}
                <div className="products-section-grid">
                    {/* <!-- Product 5 --> */}
                    <div className="products-section-product">
                        <div className="products-section-product-img-container">
                            <img src="https://placehold.co/150x150" alt="Electric Car" className="products-section-product-img"/>
                                <div className="products-section-product-actions">
                                    <button className="products-section-action-btn">
                                        <i className="far fa-heart"></i>
                                    </button>
                                    <button className="products-section-action-btn">
                                        <i className="far fa-eye"></i>
                                    </button>
                                </div>
                                <div className="products-section-new-label">
                                    NEW
                                </div>
                        </div>
                        <h3 className="products-section-product-title">Kids Electric Car</h3>
                        <div className="products-section-product-price">
                            <span>$960</span>
                        </div>
                        <div className="products-section-product-rating">
                            <div className="products-section-stars">
                                <i className="fas fa-star products-section-star-filled"></i>
                                <i className="fas fa-star products-section-star-filled"></i>
                                <i className="fas fa-star products-section-star-filled"></i>
                                <i className="fas fa-star products-section-star-filled"></i>
                                <i className="fas fa-star products-section-star-filled"></i>
                            </div>
                            <span className="products-section-review-count">(65)</span>
                        </div>
                        <div className="products-section-color-options">
                            <div className="products-section-color-option products-section-color-red-dark"></div>
                            <div className="products-section-color-option products-section-color-red-light"></div>
                        </div>
                    </div>

                    {/* <!-- Product 6 --> */}
                    <div className="products-section-product">
                        <div className="products-section-product-img-container">
                            <img src="https://placehold.co/150x150" alt="Soccer Cleats" className="products-section-product-img"/>
                                <div className="products-section-product-actions">
                                    <button className="products-section-action-btn">
                                        <i className="far fa-heart"></i>
                                    </button>
                                    <button className="products-section-action-btn">
                                        <i className="far fa-eye"></i>
                                    </button>
                                </div>
                        </div>
                        <h3 className="products-section-product-title">Jr. Zoom Soccer Cleats</h3>
                        <div className="products-section-product-price">
                            <span>$1160</span>
                        </div>
                        <div className="products-section-product-rating">
                            <div className="products-section-stars">
                                <i className="fas fa-star products-section-star-filled"></i>
                                <i className="fas fa-star products-section-star-filled"></i>
                                <i className="fas fa-star products-section-star-filled"></i>
                                <i className="fas fa-star products-section-star-filled"></i>
                                <i className="fas fa-star products-section-star-filled"></i>
                            </div>
                            <span className="products-section-review-count">(35)</span>
                        </div>
                        <div className="products-section-color-options">
                            <div className="products-section-color-option products-section-color-black"></div>
                            <div className="products-section-color-option products-section-color-red"></div>
                        </div>
                    </div>

                    {/* <!-- Product 7 --> */}
                    <div className="products-section-product">
                        <div className="products-section-product-img-container">
                            <img src="https://placehold.co/150x150" alt="Gamepad" className="products-section-product-img"/>
                                <div className="products-section-product-actions">
                                    <button className="products-section-action-btn">
                                        <i className="far fa-heart"></i>
                                    </button>
                                    <button className="products-section-action-btn">
                                        <i className="far fa-eye"></i>
                                    </button>
                                </div>
                                <div className="products-section-new-label">
                                    NEW
                                </div>
                        </div>
                        <h3 className="products-section-product-title">GP11 Shooter USB Gamepad</h3>
                        <div className="products-section-product-price">
                            <span>$660</span>
                        </div>
                        <div className="products-section-product-rating">
                            <div className="products-section-stars">
                                <i className="fas fa-star products-section-star-filled"></i>
                                <i className="fas fa-star products-section-star-filled"></i>
                                <i className="fas fa-star products-section-star-filled"></i>
                                <i className="fas fa-star products-section-star-filled"></i>
                                <i className="fas fa-star products-section-star-filled"></i>
                            </div>
                            <span className="products-section-review-count">(55)</span>
                        </div>
                        <div className="products-section-color-options">
                            <div className="products-section-color-option products-section-color-black"></div>
                            <div className="products-section-color-option products-section-color-red"></div>
                        </div>
                    </div>

                    {/* <!-- Product 8 --> */}
                    <div className="products-section-product">
                        <div className="products-section-product-img-container">
                            <img src="https://placehold.co/150x150" alt="Jacket" className="products-section-product-img"/>
                                <div className="products-section-product-actions">
                                    <button className="products-section-action-btn">
                                        <i className="far fa-heart"></i>
                                    </button>
                                    <button className="products-section-action-btn">
                                        <i className="far fa-eye"></i>
                                    </button>
                                </div>
                        </div>
                        <h3 className="products-section-product-title">Quilted Satin Jacket</h3>
                        <div className="products-section-product-price">
                            <span>$660</span>
                        </div>
                        <div className="products-section-product-rating">
                            <div className="products-section-stars">
                                <i className="fas fa-star products-section-star-filled"></i>
                                <i className="fas fa-star products-section-star-filled"></i>
                                <i className="fas fa-star products-section-star-filled"></i>
                                <i className="fas fa-star products-section-star-filled"></i>
                                <i className="fas fa-star products-section-star-filled"></i>
                            </div>
                            <span className="products-section-review-count">(55)</span>
                        </div>
                        <div className="products-section-color-options">
                            <div className="products-section-color-option products-section-color-black"></div>
                            <div className="products-section-color-option products-section-color-red"></div>
                        </div>
                    </div>
                </div>

                {/* <!-- View All Button --> */}
                <div className="products-section-view-all">
                    <button className="products-section-view-all-btn">
                        View All Products
                    </button>
                </div>
            </div>
        </>
    )
}

export default ProductsSection
