import logo from './logo.svg';
import './App.css'
import Home from '../../rohit/src/Components/Pages/home'
import About from '../../rohit/src/Components/Pages/about'
import Contact from '../../rohit/src/Components/Pages/contact'
import Error from '../../rohit/src/Components/Pages/error'
import { createBrowserRouter, RouterProvider } from 'react-router-dom';

function App() {

  const router = createBrowserRouter([
    { path: '/', element: <Home/> },
    { path: '/about', element: <About/> },
    { path: '/contact', element: <Contact/> },
    { path: '*', element: <Error/> }
  ]);
  
  return (
    <>
      <RouterProvider router={router}/>
    </>
  );
}

export default App;
